// Declaración del paquete donde se encuentra esta clase
package com.poo.java;

// Importaciones necesarias para trabajar con bases de datos y diálogos
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import java.text.SimpleDateFormat;

// Clase principal que gestiona un sistema de restaurante
public class Main {

    // Método principal GUI
    public static void main(String[] args) {
        RestauranteApp.main(args);
    }

    // Método principal de consola (opcional)
    public static void mainConsole(String[] args) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            initializeDatabase(conn);

            boolean salir = false;
            while (!salir) {
                String[] opciones = {
                    "Gestionar Clientes",
                    "Gestionar Platillos",
                    "Gestionar Pedidos",
                    "Reportes",
                    "Salir"
                };

                int opcion = JOptionPane.showOptionDialog(
                    null,
                    "Seleccione una opción:",
                    "Sistema de Gestión de Restaurante 'Delicias Gourmet'",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
                );

                switch (opcion) {
                    case 0 -> menuClientes(conn);
                    case 1 -> menuPlatillos(conn);
                    case 2 -> menuPedidos(conn);
                    case 3 -> menuReportes(conn);
                    case 4, -1 -> {
                        salir = true;
                        JOptionPane.showMessageDialog(null, "¡Gracias por usar el sistema de Delicias Gourmet!");
                    }
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error de base de datos: " + e.getMessage());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error inesperado: " + e.getMessage());

        } finally {
            try { DatabaseConnection.closeConnection(); } catch (Exception ignored) {}
        }
    }

    // ==================== ESQUEMA (con CASCADE) ====================
    public static void initializeDatabase(Connection conn) throws SQLException {
        // Tabla de clientes
        String createClientes = "CREATE TABLE IF NOT EXISTS clientes (" +
                "id SERIAL PRIMARY KEY, " +
                "nombre VARCHAR(255) NOT NULL, " +
                "correo VARCHAR(255) NOT NULL, " +
                "activo BOOLEAN DEFAULT TRUE)";

        // Tabla de platillos
        String createPlatillos = "CREATE TABLE IF NOT EXISTS platillos (" +
                "id SERIAL PRIMARY KEY, " +
                "nombre VARCHAR(255) NOT NULL UNIQUE, " +
                "precio DECIMAL(10,2) NOT NULL CHECK (precio > 0), " +
                "descripcion TEXT)";

        // Pedidos con CASCADE al borrar cliente
        String createPedidos = "CREATE TABLE IF NOT EXISTS pedidos (" +
                "id SERIAL PRIMARY KEY, " +
                "cliente_id INT REFERENCES clientes(id) ON DELETE CASCADE, " +
                "fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "total DECIMAL(10,2) DEFAULT 0)";

        // Ítems de pedido con CASCADE al borrar pedido/platillo
        String createPedidosPlatillos = "CREATE TABLE IF NOT EXISTS pedidos_platillos (" +
                "id SERIAL PRIMARY KEY, " +
                "pedido_id INT REFERENCES pedidos(id) ON DELETE CASCADE, " +
                "platillo_id INT REFERENCES platillos(id) ON DELETE CASCADE, " +
                "cantidad INT NOT NULL CHECK (cantidad > 0), " +
                "precio_unitario DECIMAL(10,2) NOT NULL)";

        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(createClientes);
            stmt.executeUpdate(createPlatillos);
            stmt.executeUpdate(createPedidos);
            stmt.executeUpdate(createPedidosPlatillos);

            // Migraciones idempotentes
            try { stmt.executeUpdate("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS activo BOOLEAN DEFAULT TRUE"); } catch (SQLException ignored) {}
            try { stmt.executeUpdate("ALTER TABLE platillos ADD COLUMN IF NOT EXISTS descripcion TEXT"); } catch (SQLException ignored) {}
        }
    }

    // ==================== MENÚS (opcional consola) ====================
    static void menuClientes(Connection conn) throws SQLException {
        int opcion;
        do {
            String input = JOptionPane.showInputDialog(
                    "===== GESTIÓN DE CLIENTES =====\n" +
                    "1. Registrar Cliente\n" +
                    "2. Ver Clientes\n" +
                    "3. Editar Cliente\n" +
                    "4. Eliminar Cliente (borra pedidos)\n" +
                    "0. Volver al Menú Principal");
            if (input == null) return;

            try {
                opcion = Integer.parseInt(input);
                switch (opcion) {
                    case 1 -> registrarCliente(conn);
                    case 2 -> verClientes(conn);
                    case 3 -> editarCliente(conn);
                    case 4 -> eliminarCliente(conn); // BORRADO FÍSICO + CASCADE
                    case 0 -> JOptionPane.showMessageDialog(null, "Volviendo al menú principal");
                    default -> JOptionPane.showMessageDialog(null, "Opción no válida");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido");
                opcion = -1;
            }
        } while (opcion != 0);
    }

    static void menuPlatillos(Connection conn) throws SQLException {
        int opcion;
        do {
            String input = JOptionPane.showInputDialog(
                    "===== GESTIÓN DE PLATILLOS =====\n" +
                    "1. Registrar Platillo\n" +
                    "2. Ver Platillos\n" +
                    "3. Editar Platillo\n" +
                    "4. Eliminar Platillo\n" +
                    "0. Volver al Menú Principal");
            if (input == null) return;

            try {
                opcion = Integer.parseInt(input);
                switch (opcion) {
                    case 1 -> registrarPlatillo(conn);
                    case 2 -> verPlatillos(conn);
                    case 3 -> editarPlatillo(conn);
                    case 4 -> eliminarPlatillo(conn);
                    case 0 -> JOptionPane.showMessageDialog(null, "Volviendo al menú principal");
                    default -> JOptionPane.showMessageDialog(null, "Opción no válida");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido");
                opcion = -1;
            }
        } while (opcion != 0);
    }

    static void menuPedidos(Connection conn) throws SQLException {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {
                "Crear Pedido",
                "Ver Pedidos",
                "Ver Detalle de Pedido",
                "Eliminar Pedido",
                "Volver al Menú Principal"
            };

            int opcion = JOptionPane.showOptionDialog(
                null,
                "Seleccione una opción:",
                "Gestión de Pedidos",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                opciones,
                opciones[0]
            );

            switch (opcion) {
                case 0 -> crearPedido(conn);
                case 1 -> verPedidos(conn);
                case 2 -> verDetallePedido(conn);
                case 3 -> eliminarPedido(conn);
                case 4, -1 -> volver = true;
            }
        }
    }

    static void menuReportes(Connection conn) throws SQLException {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {
                "Total a Pagar por Pedido",
                "Pedidos por Cliente",
                "Volver al Menú Principal"
            };

            int opcion = JOptionPane.showOptionDialog(
                null,
                "Seleccione una opción:",
                "Reportes",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                opciones,
                opciones[0]
            );

            switch (opcion) {
                case 0 -> JOptionPane.showMessageDialog(null, reporteTotalPedidos(conn));
                case 1 -> reportePedidosPorCliente(conn);
                case 2, -1 -> volver = true;
            }
        }
    }

    // ==================== CLIENTES ====================
    static void registrarCliente(Connection conn) throws SQLException {
        String nombre = JOptionPane.showInputDialog("Nombre del cliente:");
        if (nombre == null || nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío");
            return;
        }

        String correo = JOptionPane.showInputDialog("Correo electrónico:");
        if (correo == null || correo.trim().isEmpty() || !correo.contains("@")) {
            JOptionPane.showMessageDialog(null, "Correo electrónico inválido");
            return;
        }

        registrarCliente(conn, nombre, correo);
    }

    public static void registrarCliente(Connection conn, String nombre, String correo) throws SQLException {
        String sql = "INSERT INTO clientes(nombre, correo) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre.trim());
            stmt.setString(2, correo.trim());
            stmt.executeUpdate();
        }
    }

    static void verClientes(Connection conn) throws SQLException {
        StringBuilder sb = new StringBuilder("===== CLIENTES =====\n");
        String sql = "SELECT * FROM clientes WHERE activo = TRUE ORDER BY id";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (!rs.next()) {
                JOptionPane.showMessageDialog(null, "No hay clientes registrados.");
                return;
            }

            do {
                sb.append(String.format("ID: %d | Nombre: %s | Correo: %s\n",
                        rs.getInt("id"), rs.getString("nombre"), rs.getString("correo")));
            } while (rs.next());
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    static void editarCliente(Connection conn) throws SQLException {
        int id;
        try {
            id = Integer.parseInt(JOptionPane.showInputDialog("ID del cliente a editar:"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido");
            return;
        }

        if (!clienteExiste(conn, id)) {
            JOptionPane.showMessageDialog(null, "El cliente no existe");
            return;
        }

        String nombre = JOptionPane.showInputDialog("Nuevo nombre:");
        if (nombre == null || nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío");
            return;
        }

        String correo = JOptionPane.showInputDialog("Nuevo correo electrónico:");
        if (correo == null || correo.trim().isEmpty() || !correo.contains("@")) {
            JOptionPane.showMessageDialog(null, "Correo electrónico inválido");
            return;
        }

        String sql = "UPDATE clientes SET nombre = ?, correo = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre.trim());
            stmt.setString(2, correo.trim());
            stmt.setInt(3, id);
            int rows = stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, rows > 0 ? "Cliente actualizado correctamente." : "Cliente no encontrado.");
        }
    }

    // BORRADO FÍSICO de cliente: CASCADE elimina pedidos y sus ítems
    static void eliminarCliente(Connection conn) throws SQLException {
        int id;
        try {
            id = Integer.parseInt(JOptionPane.showInputDialog("ID del cliente a eliminar:"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido");
            return;
        }

        // Obtener nombre (si existe)
        String nombreCliente = null;
        try (PreparedStatement stmt = conn.prepareStatement("SELECT nombre FROM clientes WHERE id = ?")) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) nombreCliente = rs.getString("nombre");
        }
        if (nombreCliente == null) {
            JOptionPane.showMessageDialog(null, "Cliente no encontrado.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(null,
                "Se eliminará el cliente '" + nombreCliente + "' y **TODOS sus pedidos**.\n" +
                "Esta acción no se puede deshacer. ¿Desea continuar?",
                "Eliminar cliente y pedidos", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM clientes WHERE id = ?")) {
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, rows > 0 ?
                    "Cliente y pedidos asociados eliminados correctamente." :
                    "No se pudo eliminar el cliente.");
        }
    }

    private static boolean clienteExiste(Connection conn, int clienteId) throws SQLException {
        String sql = "SELECT 1 FROM clientes WHERE id = ? AND activo = TRUE";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, clienteId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    // ==================== PLATILLOS ====================
    static void registrarPlatillo(Connection conn) throws SQLException {
        String nombre = JOptionPane.showInputDialog("Nombre del platillo:");
        if (nombre == null || nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío");
            return;
        }

        String checkNombre = "SELECT 1 FROM platillos WHERE LOWER(nombre) = LOWER(?)";
        try (PreparedStatement stmt = conn.prepareStatement(checkNombre)) {
            stmt.setString(1, nombre.trim());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Ya existe un platillo con ese nombre");
                return;
            }
        }

        double precio;
        try {
            precio = Double.parseDouble(JOptionPane.showInputDialog("Precio del platillo:"));
            if (precio <= 0) {
                JOptionPane.showMessageDialog(null, "El precio debe ser mayor que cero");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Precio inválido");
            return;
        }

        String sql = "INSERT INTO platillos(nombre, precio) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre.trim());
            stmt.setDouble(2, precio);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Platillo registrado correctamente.");
        }
    }

    public static void registrarPlato(Connection conn, String nombre, double precio, String descripcion) {
        try {
            String checkNombre = "SELECT 1 FROM platillos WHERE LOWER(nombre) = LOWER(?)";
            try (PreparedStatement stmt = conn.prepareStatement(checkNombre)) {
                stmt.setString(1, nombre.trim());
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) throw new SQLException("Ya existe un platillo con ese nombre");
            }

            if (precio <= 0) throw new SQLException("El precio debe ser mayor que cero");

            String sql = "INSERT INTO platillos(nombre, precio, descripcion) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, nombre.trim());
                stmt.setDouble(2, precio);
                stmt.setString(3, descripcion != null ? descripcion.trim() : "");
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    static void verPlatillos(Connection conn) throws SQLException {
        StringBuilder sb = new StringBuilder("===== PLATILLOS =====\n");
        String sql = "SELECT * FROM platillos ORDER BY id";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (!rs.next()) {
                JOptionPane.showMessageDialog(null, "No hay platillos registrados.");
                return;
            }

            do {
                sb.append(String.format("ID: %d | Nombre: %s | Precio: $%.2f\n",
                        rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio")));
            } while (rs.next());
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    static void editarPlatillo(Connection conn) throws SQLException {
        int id;
        try {
            id = Integer.parseInt(JOptionPane.showInputDialog("ID del platillo a editar:"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido");
            return;
        }

        if (!platilloExiste(conn, id)) {
            JOptionPane.showMessageDialog(null, "El platillo no existe");
            return;
        }

        String nombre = JOptionPane.showInputDialog("Nuevo nombre:");
        if (nombre == null || nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío");
            return;
        }

        String checkNombre = "SELECT 1 FROM platillos WHERE LOWER(nombre) = LOWER(?) AND id != ?";
        try (PreparedStatement stmt = conn.prepareStatement(checkNombre)) {
            stmt.setString(1, nombre.trim());
            stmt.setInt(2, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Ya existe otro platillo con ese nombre");
                return;
            }
        }

        double precio;
        try {
            precio = Double.parseDouble(JOptionPane.showInputDialog("Nuevo precio:"));
            if (precio <= 0) {
                JOptionPane.showMessageDialog(null, "El precio debe ser mayor que cero");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Precio inválido");
            return;
        }

        String sql = "UPDATE platillos SET nombre = ?, precio = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre.trim());
            stmt.setDouble(2, precio);
            stmt.setInt(3, id);
            int rows = stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, rows > 0 ? "Platillo actualizado correctamente." : "Platillo no encontrado.");
        }
    }

    static void eliminarPlatillo(Connection conn) throws SQLException {
        int id;
        try {
            id = Integer.parseInt(JOptionPane.showInputDialog("ID del platillo a eliminar:"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido");
            return;
        }

        // Aviso si está en pedidos
        String checkPedidos = "SELECT COUNT(*) FROM pedidos_platillos WHERE platillo_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(checkPedidos)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Este platillo está en pedidos. Al eliminarlo se quitará de esos pedidos. ¿Continuar?",
                        "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                if (confirm != JOptionPane.YES_OPTION) return;
            }
        }

        String sql = "DELETE FROM platillos WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, rows > 0 ? "Platillo eliminado correctamente." : "Platillo no encontrado.");
        }
    }

    private static boolean platilloExiste(Connection conn, int platilloId) throws SQLException {
        String sql = "SELECT 1 FROM platillos WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, platilloId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }

    // ==================== PEDIDOS ====================
    public static void crearPedido(Connection conn) throws SQLException {
        // Verificar clientes activos
        String checkClientes = "SELECT COUNT(*) FROM clientes WHERE activo = TRUE";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(checkClientes)) {
            if (rs.next() && rs.getInt(1) == 0) {
                JOptionPane.showMessageDialog(null, "No hay clientes registrados. Registre un cliente primero.");
                return;
            }
        }

        // Verificar platillos
        String checkPlatillos = "SELECT COUNT(*) FROM platillos";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(checkPlatillos)) {
            if (rs.next() && rs.getInt(1) == 0) {
                JOptionPane.showMessageDialog(null, "No hay platillos registrados. Registre platillos primero.");
                return;
            }
        }

        // Seleccionar cliente
        int clienteId;
        try {
            StringBuilder sbClientes = new StringBuilder("Clientes disponibles:\n");
            String sqlClientes = "SELECT id, nombre FROM clientes WHERE activo = TRUE ORDER BY id";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlClientes)) {
                while (rs.next()) {
                    sbClientes.append(String.format("%d. %s\n", rs.getInt("id"), rs.getString("nombre")));
                }
            }
            clienteId = Integer.parseInt(JOptionPane.showInputDialog(sbClientes.toString() + "\nIngrese el ID del cliente:"));
            if (!clienteExiste(conn, clienteId)) {
                JOptionPane.showMessageDialog(null, "El cliente seleccionado no existe.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID de cliente inválido");
            return;
        }

        // Crear pedido
        int pedidoId = -1;
        String sqlPedido = "INSERT INTO pedidos(cliente_id) VALUES (?) RETURNING id";
        try (PreparedStatement stmt = conn.prepareStatement(sqlPedido)) {
            stmt.setInt(1, clienteId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                pedidoId = rs.getInt(1);
            } else {
                JOptionPane.showMessageDialog(null, "Error al crear el pedido.");
                return;
            }
        }

        // Agregar platillos al pedido
        ArrayList<Integer> platillosAgregados = new ArrayList<>();
        double totalPedido = 0;

        boolean seguirAgregando = true;
        while (seguirAgregando) {
            StringBuilder sbPlatillos = new StringBuilder("Platillos disponibles:\n");
            String sqlPlatillos = "SELECT id, nombre, precio FROM platillos ORDER BY id";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlPlatillos)) {
                while (rs.next()) {
                    sbPlatillos.append(String.format("%d. %s - $%.2f\n",
                            rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio")));
                }
            }

            int platilloId;
            try {
                platilloId = Integer.parseInt(JOptionPane.showInputDialog(sbPlatillos.toString() +
                        "\nPlatillos ya agregados: " + platillosAgregados +
                        "\nIngrese el ID del platillo a agregar (0 para terminar):"));
                if (platilloId == 0) break;
                if (!platilloExiste(conn, platilloId)) {
                    JOptionPane.showMessageDialog(null, "El platillo seleccionado no existe.");
                    continue;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "ID de platillo inválido");
                continue;
            }

            int cantidad;
            try {
                cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad:"));
                if (cantidad <= 0) {
                    JOptionPane.showMessageDialog(null, "La cantidad debe ser mayor que cero");
                    continue;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Cantidad inválida");
                continue;
            }

            double precioUnitario = 0;
            String sqlPrecio = "SELECT precio FROM platillos WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPrecio)) {
                stmt.setInt(1, platilloId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    precioUnitario = rs.getDouble("precio");
                }
            }

            String sqlDetalle = "INSERT INTO pedidos_platillos(pedido_id, platillo_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlDetalle)) {
                stmt.setInt(1, pedidoId);
                stmt.setInt(2, platilloId);
                stmt.setInt(3, cantidad);
                stmt.setDouble(4, precioUnitario);
                stmt.executeUpdate();

                platillosAgregados.add(platilloId);
                totalPedido += precioUnitario * cantidad;

                JOptionPane.showMessageDialog(null, "Platillo agregado al pedido.");
            }

            int continuar = JOptionPane.showConfirmDialog(null, "¿Desea agregar otro platillo?",
                    "Agregar platillo", JOptionPane.YES_NO_OPTION);
            seguirAgregando = (continuar == JOptionPane.YES_OPTION);
        }

        if (platillosAgregados.isEmpty()) {
            // Eliminar el pedido vacío (borrado físico)
            String sqlEliminar = "DELETE FROM pedidos WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlEliminar)) {
                stmt.setInt(1, pedidoId);
                stmt.executeUpdate();
            }
            JOptionPane.showMessageDialog(null, "El pedido debe tener al menos un platillo. Pedido cancelado.");
            return;
        }

        // Actualizar total
        String sqlTotal = "UPDATE pedidos SET total = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sqlTotal)) {
            stmt.setDouble(1, totalPedido);
            stmt.setInt(2, pedidoId);
            stmt.executeUpdate();
        }

        JOptionPane.showMessageDialog(null, String.format("Pedido #%d creado correctamente.\nTotal: $%.2f", pedidoId, totalPedido));
    }

    static void verPedidos(Connection conn) throws SQLException {
        StringBuilder sb = new StringBuilder("===== PEDIDOS =====\n");
        String sql = "SELECT p.id, p.fecha, c.nombre AS cliente, p.total " +
                     "FROM pedidos p JOIN clientes c ON p.cliente_id = c.id " +
                     "ORDER BY p.fecha DESC";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (!rs.next()) {
                JOptionPane.showMessageDialog(null, "No hay pedidos registrados.");
                return;
            }

            do {
                Timestamp timestamp = rs.getTimestamp("fecha");
                String fechaFormateada = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(timestamp);

                sb.append(String.format("Pedido #%d | Fecha: %s | Cliente: %s | Total: $%.2f\n",
                        rs.getInt("id"), fechaFormateada, rs.getString("cliente"), rs.getDouble("total")));
            } while (rs.next());
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // Ver detalle pidiendo ID por diálogo (consola/menú)
    public static void verDetallePedido(Connection conn) throws SQLException {
        int pedidoId;
        try {
            pedidoId = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del pedido:"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID de pedido inválido");
            return;
        }

        // Reusar método que arma el string
        String detalle = verDetallePedido(conn, pedidoId);
        JOptionPane.showMessageDialog(null, detalle);
    }

    // Ver detalle (para UI Swing)
    public static String verDetallePedido(Connection conn, int pedidoId) {
        try {
            String checkPedido = "SELECT p.id, p.fecha, c.nombre AS cliente, p.total " +
                                "FROM pedidos p JOIN clientes c ON p.cliente_id = c.id " +
                                "WHERE p.id = ?";

            try (PreparedStatement stmt = conn.prepareStatement(checkPedido)) {
                stmt.setInt(1, pedidoId);
                ResultSet rs = stmt.executeQuery();

                if (!rs.next()) {
                    return "El pedido no existe.";
                }

                Timestamp timestamp = rs.getTimestamp("fecha");
                String fechaFormateada = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(timestamp);

                StringBuilder sb = new StringBuilder();
                sb.append(String.format("===== DETALLE DE PEDIDO #%d =====\n", pedidoId));
                sb.append(String.format("Fecha: %s\n", fechaFormateada));
                sb.append(String.format("Cliente: %s\n", rs.getString("cliente")));
                sb.append("\n--- PLATILLOS ---\n");

                String sqlDetalle = "SELECT pl.nombre, pp.cantidad, pp.precio_unitario, (pp.cantidad * pp.precio_unitario) AS subtotal " +
                                   "FROM pedidos_platillos pp " +
                                   "JOIN platillos pl ON pp.platillo_id = pl.id " +
                                   "WHERE pp.pedido_id = ?";

                try (PreparedStatement stmtDetalle = conn.prepareStatement(sqlDetalle)) {
                    stmtDetalle.setInt(1, pedidoId);
                    ResultSet rsDetalle = stmtDetalle.executeQuery();

                    while (rsDetalle.next()) {
                        sb.append(String.format("%s - %d x $%.2f = $%.2f\n",
                                rsDetalle.getString("nombre"),
                                rsDetalle.getInt("cantidad"),
                                rsDetalle.getDouble("precio_unitario"),
                                rsDetalle.getDouble("subtotal")));
                    }
                }

                sb.append(String.format("\nTOTAL: $%.2f", rs.getDouble("total")));

                return sb.toString();
            }
        } catch (SQLException e) {
            return "Error al obtener el detalle del pedido: " + e.getMessage();
        }
    }

    static void eliminarPedido(Connection conn) throws SQLException {
        // Mostrar lista breve
        StringBuilder sb = new StringBuilder("Pedidos disponibles (ID - Cliente - Total):\n");
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT p.id, c.nombre, p.total FROM pedidos p JOIN clientes c ON c.id=p.cliente_id ORDER BY p.id DESC LIMIT 30")) {
            while (rs.next()) {
                sb.append(String.format("%d - %s - $%.2f%n", rs.getInt(1), rs.getString(2), rs.getDouble(3)));
            }
        }

        int pedidoId;
        try {
            pedidoId = Integer.parseInt(JOptionPane.showInputDialog(sb + "\nIngrese el ID del pedido a eliminar:"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID de pedido inválido");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(null,
                "¿Está seguro de eliminar este pedido? Esta acción no se puede deshacer.",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM pedidos WHERE id=?")) {
            ps.setInt(1, pedidoId);
            int n = ps.executeUpdate();
            JOptionPane.showMessageDialog(null, n > 0 ? "Pedido eliminado correctamente." : "No se encontró el pedido.");
        }
    }

    // ==================== REPORTES ====================
    public static String reporteTotalPedidos(Connection conn) {
        try {
            StringBuilder sb = new StringBuilder("===== REPORTE: TOTAL POR PEDIDO =====\n\n");
            String sql = "SELECT p.id, p.fecha, c.nombre AS cliente, p.total " +
                         "FROM pedidos p JOIN clientes c ON p.cliente_id = c.id " +
                         "ORDER BY p.total DESC";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {

                if (!rs.next()) {
                    return "No hay pedidos registrados.";
                }

                do {
                    Timestamp timestamp = rs.getTimestamp("fecha");
                    String fechaFormateada = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(timestamp);

                    sb.append(String.format("Pedido #%d | Fecha: %s | Cliente: %s | Total: $%.2f\n",
                            rs.getInt("id"), fechaFormateada, rs.getString("cliente"), rs.getDouble("total")));
                } while (rs.next());
            }

            return sb.toString();
        } catch (SQLException e) {
            return "Error al generar el reporte: " + e.getMessage();
        }
    }

    public static void reportePedidosPorCliente(Connection conn) throws SQLException {
        // Seleccionar cliente
        int clienteId;
        try {
            StringBuilder sbClientes = new StringBuilder("Clientes disponibles:\n");
            String sqlClientes = "SELECT id, nombre FROM clientes ORDER BY id";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlClientes)) {

                if (!rs.next()) {
                    JOptionPane.showMessageDialog(null, "No hay clientes registrados.");
                    return;
                }

                do {
                    sbClientes.append(String.format("%d. %s\n", rs.getInt("id"), rs.getString("nombre")));
                } while (rs.next());
            }

            clienteId = Integer.parseInt(JOptionPane.showInputDialog(sbClientes.toString() + "\nIngrese el ID del cliente:"));

            if (!clienteExiste(conn, clienteId)) {
                JOptionPane.showMessageDialog(null, "El cliente seleccionado no existe.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID de cliente inválido");
            return;
        }

        // Obtener nombre del cliente
        String nombreCliente = "";
        String sqlCliente = "SELECT nombre FROM clientes WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sqlCliente)) {
            stmt.setInt(1, clienteId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                nombreCliente = rs.getString("nombre");
            }
        }

        // Generar reporte
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("===== PEDIDOS DEL CLIENTE: %s =====\n\n", nombreCliente));

        String sql = "SELECT p.id, p.fecha, p.total, COUNT(pp.id) AS num_platillos " +
                     "FROM pedidos p " +
                     "JOIN pedidos_platillos pp ON p.id = pp.pedido_id " +
                     "WHERE p.cliente_id = ? " +
                     "GROUP BY p.id, p.fecha, p.total " +
                     "ORDER BY p.fecha DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, clienteId);
            ResultSet rs = stmt.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(null, "Este cliente no tiene pedidos registrados.");
                return;
            }

            do {
                Timestamp timestamp = rs.getTimestamp("fecha");
                String fechaFormateada = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(timestamp);

                sb.append(String.format("Pedido #%d | Fecha: %s | Platillos: %d | Total: $%.2f\n",
                        rs.getInt("id"), fechaFormateada, rs.getInt("num_platillos"), rs.getDouble("total")));
            } while (rs.next());
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // Para UI (no muestra diálogos)
    public static String reportePedidosPorCliente(Connection conn, int clienteId) {
        try {
            if (!clienteExiste(conn, clienteId)) {
                return "El cliente seleccionado no existe.";
            }

            String nombreCliente = "";
            String sqlCliente = "SELECT nombre FROM clientes WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCliente)) {
                stmt.setInt(1, clienteId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    nombreCliente = rs.getString("nombre");
                }
            }

            StringBuilder sb = new StringBuilder();
            sb.append(String.format("===== PEDIDOS DEL CLIENTE: %s =====\n\n", nombreCliente));

            String sql = "SELECT p.id, p.fecha, p.total, COUNT(pp.id) AS num_platillos " +
                         "FROM pedidos p " +
                         "JOIN pedidos_platillos pp ON p.id = pp.pedido_id " +
                         "WHERE p.cliente_id = ? " +
                         "GROUP BY p.id, p.fecha, p.total " +
                         "ORDER BY p.fecha DESC";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, clienteId);
                ResultSet rs = stmt.executeQuery();

                if (!rs.next()) {
                    return "Este cliente no tiene pedidos registrados.";
                }

                do {
                    Timestamp timestamp = rs.getTimestamp("fecha");
                    String fechaFormateada = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(timestamp);

                    sb.append(String.format("Pedido #%d | Fecha: %s | Platillos: %d | Total: $%.2f\n",
                            rs.getInt("id"), fechaFormateada, rs.getInt("num_platillos"), rs.getDouble("total")));
                } while (rs.next());
            }

            return sb.toString();
        } catch (SQLException e) {
            return "Error al generar el reporte: " + e.getMessage();
        }
    }
}
