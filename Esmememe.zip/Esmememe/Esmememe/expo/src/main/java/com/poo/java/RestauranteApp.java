package com.poo.java;

// Importaciones necesarias para la interfaz gráfica y base de datos
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class RestauranteApp extends JFrame {
    // Componentes de la interfaz gráfica
    private JTabbedPane tabbedPane;
    private DefaultTableModel clientesModel, platosModel, pedidosModel;
    private JTable clientesTable, platosTable, pedidosTable;
    private Connection conn;

    public RestauranteApp() {
        // Look and feel del sistema
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        setTitle("🍽️ Sistema de Gestión de Restaurante - Delicias Gourmet");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(1000, 600));

        setupUIDefaults();

        // Conexión y creación de tablas
        try {
            conn = DatabaseConnection.getConnection();
            Main.initializeDatabase(conn);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
            System.exit(1);
        }

        initializeComponents();
        loadData();
        setVisible(true);
    }

    private void setupUIDefaults() {
        Color primaryColor = new Color(41, 128, 185);
        Color secondaryColor = new Color(52, 73, 94);
        Color backgroundColor = new Color(236, 240, 241);
        Color cardColor = Color.WHITE;

        UIManager.put("Panel.background", backgroundColor);
        UIManager.put("TabbedPane.background", backgroundColor);
        UIManager.put("TabbedPane.selected", primaryColor);
        UIManager.put("TabbedPane.foreground", secondaryColor);
        UIManager.put("Button.background", primaryColor);
        UIManager.put("Button.foreground", Color.BLACK);
        UIManager.put("Table.background", cardColor);
        UIManager.put("Table.gridColor", new Color(189, 195, 199));
        UIManager.put("Table.selectionBackground", new Color(52, 152, 219));
        UIManager.put("Table.selectionForeground", Color.BLACK);

        Font defaultFont = new Font("Segoe UI", Font.PLAIN, 12);
        Font headerFont = new Font("Segoe UI", Font.BOLD, 14);
        UIManager.put("Label.font", defaultFont);
        UIManager.put("Button.font", defaultFont);
        UIManager.put("Table.font", defaultFont);
        UIManager.put("TableHeader.font", headerFont);
    }

    private void initializeComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(new Color(236, 240, 241));

        JPanel headerPanel = createHeaderPanel();

        tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabbedPane.setBorder(new EmptyBorder(10, 0, 0, 0));

        tabbedPane.addTab("👥 Clientes", createClientesPanel());
        tabbedPane.addTab("🍽️ Platos", createPlatosPanel());
        tabbedPane.addTab("📋 Pedidos", createPedidosPanel());
        tabbedPane.addTab("📊 Reportes", createReportesPanel());

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        add(mainPanel, BorderLayout.CENTER);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setBorder(new EmptyBorder(20, 25, 20, 25));

        JLabel titleLabel = new JLabel("Sistema de Gestión de Restaurante");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.BLACK);

        JLabel subtitleLabel = new JLabel("Delicias Gourmet - Gestión Integral");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(new Color(236, 240, 241));

        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setOpaque(false);
        textPanel.add(titleLabel, BorderLayout.NORTH);
        textPanel.add(subtitleLabel, BorderLayout.CENTER);

        headerPanel.add(textPanel, BorderLayout.WEST);

        return headerPanel;
    }

    private JPanel createSectionHeader(String title, String description) {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(52, 73, 94));

        JLabel descLabel = new JLabel(description);
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(new Color(127, 140, 141));

        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setOpaque(false);
        textPanel.add(titleLabel, BorderLayout.NORTH);
        textPanel.add(descLabel, BorderLayout.CENTER);

        headerPanel.add(textPanel, BorderLayout.WEST);
        return headerPanel;
    }

    private JButton createStyledButton(String text, Color bgColor, Color textColor) {
        JButton button = new JButton(text);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(true);
        button.setBackground(bgColor);
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createRaisedBevelBorder(),
                new EmptyBorder(8, 16, 8, 16)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(170, 35));

        button.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { button.setBackground(bgColor.darker()); }
            @Override public void mouseExited(MouseEvent e)  { button.setBackground(bgColor); }
        });

        return button;
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(35);
        table.setShowGrid(true);
        table.setGridColor(new Color(236, 240, 241));
        table.setSelectionBackground(new Color(52, 152, 219));
        table.setSelectionForeground(Color.BLACK);
        table.setBackground(Color.WHITE);

        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(52, 73, 94));
        table.getTableHeader().setForeground(Color.BLACK);
        table.getTableHeader().setPreferredSize(new Dimension(0, 40));
        table.getTableHeader().setBorder(new EmptyBorder(0, 0, 0, 0));
    }

    // ===================== PESTAÑA: CLIENTES =====================
    private JPanel createClientesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel headerPanel = createSectionHeader("Gestión de Clientes", "Administra la información de tus clientes");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton addBtn = createStyledButton("➕ Agregar Cliente", new Color(46, 204, 113), Color.BLACK);
        JButton editBtn = createStyledButton("✏️ Editar Cliente", new Color(241, 196, 15), Color.BLACK);
        JButton deleteBtn = createStyledButton("🗑️ Eliminar Cliente", new Color(231, 76, 60), Color.BLACK);

        addBtn.addActionListener(e -> agregarCliente());
        editBtn.addActionListener(e -> editarClienteSeleccionado());
        deleteBtn.addActionListener(e -> eliminarCliente());

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);

        String[] columns = {"ID", "Nombre", "Correo"};
        clientesModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        clientesTable = new JTable(clientesModel);
        styleTable(clientesTable);

        JScrollPane scrollPane = new JScrollPane(clientesTable);
        scrollPane.setBorder(new LineBorder(new Color(189, 195, 199), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);

        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);
        return panel;
    }

    // ===================== PESTAÑA: PLATOS =====================
    private JPanel createPlatosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel headerPanel = createSectionHeader("Gestión de Platos", "Administra el menú y precios de tu restaurante");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton addBtn = createStyledButton("➕ Agregar Plato", new Color(46, 204, 113), Color.BLACK);
        JButton editBtn = createStyledButton("✏️ Editar Plato", new Color(241, 196, 15), Color.BLACK);
        JButton deleteBtn = createStyledButton("🗑️ Eliminar Plato", new Color(231, 76, 60), Color.BLACK);

        addBtn.addActionListener(e -> agregarPlato());
        editBtn.addActionListener(e -> editarPlatoSeleccionado());
        deleteBtn.addActionListener(e -> eliminarPlato());

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);

        String[] columns = {"ID", "Nombre", "Precio", "Descripción"};
        platosModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        platosTable = new JTable(platosModel);
        styleTable(platosTable);

        JScrollPane scrollPane = new JScrollPane(platosTable);
        scrollPane.setBorder(new LineBorder(new Color(189, 195, 199), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);

        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);
        return panel;
    }

    // ===================== PESTAÑA: PEDIDOS =====================
    private JPanel createPedidosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel headerPanel = createSectionHeader("Gestión de Pedidos", "Administra los pedidos y órdenes de los clientes");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton addBtn = createStyledButton("➕ Crear Pedido", new Color(46, 204, 113), Color.BLACK);
        JButton viewBtn = createStyledButton("👁️ Ver Detalle", new Color(155, 89, 182), Color.BLACK);
        JButton modifyItemsBtn = createStyledButton("🛠️ Modificar Ítems", new Color(52, 73, 94), Color.BLACK);
        JButton deleteBtn = createStyledButton("🗑️ Eliminar Pedido", new Color(231, 76, 60), Color.BLACK);

        addBtn.addActionListener(e -> crearPedido());
        viewBtn.addActionListener(e -> verDetallePedido());
        modifyItemsBtn.addActionListener(e -> modificarItemsPedidoSeleccionado());
        deleteBtn.addActionListener(e -> eliminarPedido());

        buttonPanel.add(addBtn);
        buttonPanel.add(viewBtn);
        buttonPanel.add(modifyItemsBtn);
        buttonPanel.add(deleteBtn);

        String[] columns = {"ID", "Cliente", "Fecha", "Total"};
        pedidosModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        pedidosTable = new JTable(pedidosModel);
        styleTable(pedidosTable);

        JScrollPane scrollPane = new JScrollPane(pedidosTable);
        scrollPane.setBorder(new LineBorder(new Color(189, 195, 199), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);

        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);
        return panel;
    }

    // ===================== PESTAÑA: REPORTES =====================
    private JPanel createReportesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel headerPanel = createSectionHeader("Reportes y Estadísticas", "Genera reportes detallados del negocio");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton totalBtn = createStyledButton("💰 Reporte Total", new Color(230, 126, 34), Color.BLACK);
        JButton clienteBtn = createStyledButton("👤 Por Cliente", new Color(142, 68, 173), Color.BLACK);

        totalBtn.addActionListener(e -> mostrarReporteTotal());
        clienteBtn.addActionListener(e -> mostrarReportePorCliente());

        buttonPanel.add(totalBtn);
        buttonPanel.add(clienteBtn);

        JTextArea reporteArea = new JTextArea(
                "📊 Seleccione un tipo de reporte para visualizar los datos.\n\n" +
                "• Reporte Total: Muestra estadísticas generales de todos los pedidos\n" +
                "• Por Cliente: Muestra el historial de pedidos de un cliente específico");
        reporteArea.setEditable(false);
        reporteArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        reporteArea.setBackground(new Color(248, 249, 250));
        reporteArea.setBorder(new EmptyBorder(15, 15, 15, 15));
        reporteArea.setForeground(new Color(52, 73, 94));

        JScrollPane scrollPane = new JScrollPane(reporteArea);
        scrollPane.setBorder(new LineBorder(new Color(189, 195, 199), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);

        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);
        return panel;
    }

    // ===================== CARGA INICIAL =====================
    private void loadData() {
        loadClientes();
        loadPlatos();
        loadPedidos();
    }

    private void loadClientes() {
        clientesModel.setRowCount(0);
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT id, nombre, correo FROM clientes WHERE activo = TRUE ORDER BY id");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                clientesModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("correo")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar clientes: " + e.getMessage());
        }
    }

    private void loadPlatos() {
        platosModel.setRowCount(0);
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT id, nombre, precio, descripcion FROM platillos ORDER BY id");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                platosModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        String.format("$%.2f", rs.getDouble("precio")),
                        rs.getString("descripcion")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar platos: " + e.getMessage());
        }
    }

    private void loadPedidos() {
        pedidosModel.setRowCount(0);
        String sql = "SELECT p.id, c.nombre as cliente, p.fecha, p.total " +
                     "FROM pedidos p JOIN clientes c ON p.cliente_id = c.id " +
                     "ORDER BY p.id DESC";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                pedidosModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("cliente"),
                        rs.getTimestamp("fecha"),
                        String.format("$%.2f", rs.getDouble("total"))
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar pedidos: " + e.getMessage());
        }
    }

    // ===================== ACCIONES: CLIENTES =====================
    private void agregarCliente() {
        String nombre = JOptionPane.showInputDialog(this, "Nombre del cliente:");
        if (nombre == null || nombre.trim().isEmpty()) return;

        String correo = JOptionPane.showInputDialog(this, "Correo del cliente:");
        if (correo == null || correo.trim().isEmpty() || !correo.contains("@")) {
            JOptionPane.showMessageDialog(this, "Correo inválido");
            return;
        }

        try {
            Main.registrarCliente(conn, nombre.trim(), correo.trim());
            loadClientes();
            JOptionPane.showMessageDialog(this, "Cliente agregado exitosamente");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al agregar cliente: " + e.getMessage());
        }
    }

    private void editarClienteSeleccionado() {
        int row = clientesTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente de la tabla.");
            return;
        }

        int id = (Integer) clientesModel.getValueAt(row, 0);
        String nombreActual = (String) clientesModel.getValueAt(row, 1);
        String correoActual = (String) clientesModel.getValueAt(row, 2);

        String nuevoNombre = JOptionPane.showInputDialog(this, "Nuevo nombre:", nombreActual);
        if (nuevoNombre == null || nuevoNombre.trim().isEmpty()) return;

        String nuevoCorreo = JOptionPane.showInputDialog(this, "Nuevo correo:", correoActual);
        if (nuevoCorreo == null || nuevoCorreo.trim().isEmpty() || !nuevoCorreo.contains("@")) {
            JOptionPane.showMessageDialog(this, "Correo inválido.");
            return;
        }

        String sql = "UPDATE clientes SET nombre = ?, correo = ? WHERE id = ? AND activo = TRUE";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nuevoNombre.trim());
            ps.setString(2, nuevoCorreo.trim());
            ps.setInt(3, id);
            int n = ps.executeUpdate();
            if (n > 0) {
                JOptionPane.showMessageDialog(this, "Cliente actualizado correctamente.");
                loadClientes();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo actualizar (¿cliente inactivo?).");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al actualizar: " + ex.getMessage());
        }
    }

    private void eliminarCliente() {
        int selectedRow = clientesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente");
            return;
        }

        int clienteId = (Integer) clientesModel.getValueAt(selectedRow, 0);
        String nombreCliente = (String) clientesModel.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Esta acción eliminará al cliente '" + nombreCliente + "' y **TODOS sus pedidos**.\n" +
                "¿Desea continuar?",
                "Eliminar cliente y sus pedidos", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM clientes WHERE id = ?")) {
                stmt.setInt(1, clienteId);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Cliente y pedidos asociados eliminados correctamente.");
                    loadClientes();
                    loadPedidos(); // refrescar también pedidos
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo eliminar el cliente.");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar cliente: " + e.getMessage());
            }
        }
    }

    // ===================== ACCIONES: PLATOS =====================
    private void agregarPlato() {
        String nombre = JOptionPane.showInputDialog(this, "Nombre del plato:");
        if (nombre == null || nombre.trim().isEmpty()) return;

        String precioStr = JOptionPane.showInputDialog(this, "Precio del plato:");
        if (precioStr == null || precioStr.trim().isEmpty()) return;

        String descripcion = JOptionPane.showInputDialog(this, "Descripción del plato:");
        if (descripcion == null) descripcion = "";

        try {
            double precio = Double.parseDouble(precioStr);
            Main.registrarPlato(conn, nombre.trim(), precio, descripcion.trim());
            loadPlatos();
            JOptionPane.showMessageDialog(this, "Plato agregado exitosamente");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio inválido");
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(this, "Error al agregar plato: " + e.getMessage());
        }
    }

    private void editarPlatoSeleccionado() {
        int row = platosTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un plato de la tabla.");
            return;
        }

        int id = (Integer) platosModel.getValueAt(row, 0);
        String nombreActual = (String) platosModel.getValueAt(row, 1);
        String precioActualStr = ((String) platosModel.getValueAt(row, 2)).replace("$", "");
        String descActual = (String) platosModel.getValueAt(row, 3);

        String nuevoNombre = JOptionPane.showInputDialog(this, "Nuevo nombre:", nombreActual);
        if (nuevoNombre == null || nuevoNombre.trim().isEmpty()) return;

        String nuevoPrecioStr = JOptionPane.showInputDialog(this, "Nuevo precio:", precioActualStr);
        if (nuevoPrecioStr == null || nuevoPrecioStr.trim().isEmpty()) return;

        double nuevoPrecio;
        try {
            nuevoPrecio = Double.parseDouble(nuevoPrecioStr);
            if (nuevoPrecio <= 0) {
                JOptionPane.showMessageDialog(this, "El precio debe ser mayor que cero.");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Precio inválido.");
            return;
        }

        String nuevaDesc = JOptionPane.showInputDialog(this, "Nueva descripción (opcional):", descActual);
        if (nuevaDesc == null) nuevaDesc = "";

        // Validar nombre duplicado (otro registro distinto a id)
        String check = "SELECT 1 FROM platillos WHERE LOWER(nombre)=LOWER(?) AND id<>?";
        try (PreparedStatement chk = conn.prepareStatement(check)) {
            chk.setString(1, nuevoNombre.trim());
            chk.setInt(2, id);
            try (ResultSet rs = chk.executeQuery()) {
                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, "Ya existe otro platillo con ese nombre.");
                    return;
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error validando nombre: " + ex.getMessage());
            return;
        }

        String sql = "UPDATE platillos SET nombre = ?, precio = ?, descripcion = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nuevoNombre.trim());
            ps.setDouble(2, nuevoPrecio);
            ps.setString(3, nuevaDesc.trim());
            ps.setInt(4, id);
            int n = ps.executeUpdate();
            if (n > 0) {
                JOptionPane.showMessageDialog(this, "Plato actualizado correctamente.");
                loadPlatos();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo actualizar el plato.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al actualizar: " + ex.getMessage());
        }
    }

    private void eliminarPlato() {
        int selectedRow = platosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un plato");
            return;
        }

        int platoId = (Integer) platosModel.getValueAt(selectedRow, 0);
        String nombrePlato = (String) platosModel.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de eliminar el plato: " + nombrePlato + "?\n" +
                "Esta acción también lo eliminará de todos los pedidos.",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM platillos WHERE id = ?")) {
                stmt.setInt(1, platoId);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Plato eliminado correctamente.");
                    loadPlatos();
                    loadPedidos(); // por si afectó subtotales previos
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo eliminar el plato.");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar plato: " + e.getMessage());
            }
        }
    }

    // ===================== ACCIONES: PEDIDOS =====================
    private void crearPedido() {
        try {
            Main.crearPedido(conn);
            loadPedidos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al crear pedido: " + e.getMessage());
        }
    }

    private void verDetallePedido() {
        int selectedRow = pedidosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un pedido");
            return;
        }

        int pedidoId = (Integer) pedidosModel.getValueAt(selectedRow, 0);
        String detalle = Main.verDetallePedido(conn, pedidoId);

        JTextArea textArea = new JTextArea(detalle);
        textArea.setEditable(false);
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 380));

        JOptionPane.showMessageDialog(this, scrollPane, "Detalle del Pedido", JOptionPane.INFORMATION_MESSAGE);
    }

    // Editor de ítems del pedido (agregar, cambiar cantidad, eliminar y recalcular total)
    private void modificarItemsPedidoSeleccionado() {
        int row = pedidosTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un pedido de la tabla.");
            return;
        }
        int pedidoId = (Integer) pedidosModel.getValueAt(row, 0);

        while (true) {
            String resumen = obtenerResumenItemsPedido(pedidoId);
            String[] opciones = {"Agregar platillo", "Cambiar cantidad", "Eliminar platillo", "Finalizar"};
            int op = JOptionPane.showOptionDialog(
                    this,
                    "Pedido #" + pedidoId + " - Ítems actuales:\n\n" + resumen +
                            "\n\nElige una acción:",
                    "Modificar Ítems del Pedido",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, opciones, opciones[0]
            );

            if (op == 0) { // Agregar platillo
                agregarPlatilloAPedido(pedidoId);
            } else if (op == 1) { // Cambiar cantidad
                cambiarCantidadDeItem(pedidoId);
            } else if (op == 2) { // Eliminar platillo
                eliminarItemDePedido(pedidoId);
            } else { // Finalizar
                try {
                    if (!existenItemsEnPedido(pedidoId)) {
                        int r = JOptionPane.showConfirmDialog(this,
                                "El pedido se quedará sin ítems. ¿Desea eliminar el pedido?",
                                "Pedido vacío", JOptionPane.YES_NO_OPTION);
                        if (r == JOptionPane.YES_OPTION) {
                            try (PreparedStatement d = conn.prepareStatement("DELETE FROM pedidos WHERE id=?")) {
                                d.setInt(1, pedidoId);
                                d.executeUpdate();
                            }
                            JOptionPane.showMessageDialog(this, "Pedido eliminado.");
                            loadPedidos();
                            return;
                        } else {
                            continue;
                        }
                    }
                    // Recalcular total y salir
                    recalcularTotalPedido(pedidoId);
                    loadPedidos();
                    JOptionPane.showMessageDialog(this, "Ítems actualizados y total recalculado.");
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error al finalizar: " + e.getMessage());
                }
                return;
            }
        }
    }

    private String obtenerResumenItemsPedido(int pedidoId) {
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT pl.id AS platillo_id, pl.nombre, pp.cantidad, pp.precio_unitario, " +
                     "(pp.cantidad * pp.precio_unitario) AS subtotal " +
                     "FROM pedidos_platillos pp " +
                     "JOIN platillos pl ON pl.id = pp.platillo_id " +
                     "WHERE pp.pedido_id = ? ORDER BY pl.id";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pedidoId);
            try (ResultSet rs = ps.executeQuery()) {
                boolean any = false;
                while (rs.next()) {
                    any = true;
                    sb.append(String.format("ID:%d | %s | Cant:%d | P.Unit:$%.2f | Sub:$%.2f%n",
                            rs.getInt("platillo_id"),
                            rs.getString("nombre"),
                            rs.getInt("cantidad"),
                            rs.getDouble("precio_unitario"),
                            rs.getDouble("subtotal")));
                }
                if (!any) sb.append("(sin ítems)");
            }
        } catch (SQLException e) {
            sb.append("Error al cargar ítems: ").append(e.getMessage());
        }
        return sb.toString();
    }

    private boolean existenItemsEnPedido(int pedidoId) throws SQLException {
        String sql = "SELECT 1 FROM pedidos_platillos WHERE pedido_id = ? LIMIT 1";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pedidoId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    private void agregarPlatilloAPedido(int pedidoId) {
        // Mostrar platillos disponibles
        StringBuilder lista = new StringBuilder("Platillos disponibles:\n");
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, nombre, precio FROM platillos ORDER BY id")) {
            while (rs.next()) {
                lista.append(String.format("%d. %s - $%.2f%n", rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio")));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando platillos: " + e.getMessage());
            return;
        }

        int platilloId;
        try {
            String s = JOptionPane.showInputDialog(this, lista + "\nIngrese ID de platillo a agregar:");
            if (s == null) return;
            platilloId = Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID inválido.");
            return;
        }

        int cantidad;
        try {
            String s = JOptionPane.showInputDialog(this, "Cantidad (>0):");
            if (s == null) return;
            cantidad = Integer.parseInt(s);
            if (cantidad <= 0) { JOptionPane.showMessageDialog(this, "La cantidad debe ser > 0."); return; }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Cantidad inválida.");
            return;
        }

        try {
            // Precio actual del platillo
            double precio;
            try (PreparedStatement ps = conn.prepareStatement("SELECT precio FROM platillos WHERE id=?")) {
                ps.setInt(1, platilloId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) { JOptionPane.showMessageDialog(this, "El platillo no existe."); return; }
                    precio = rs.getDouble("precio");
                }
            }

            // Si ya existe en el pedido, sumar cantidad; si no, insertar
            try (PreparedStatement chk = conn.prepareStatement(
                    "SELECT id, cantidad FROM pedidos_platillos WHERE pedido_id=? AND platillo_id=?")) {
                chk.setInt(1, pedidoId);
                chk.setInt(2, platilloId);
                try (ResultSet rs = chk.executeQuery()) {
                    if (rs.next()) {
                        int detalleId = rs.getInt("id");
                        int nuevaCant = rs.getInt("cantidad") + cantidad;
                        try (PreparedStatement up = conn.prepareStatement(
                                "UPDATE pedidos_platillos SET cantidad=? WHERE id=?")) {
                            up.setInt(1, nuevaCant);
                            up.setInt(2, detalleId);
                            up.executeUpdate();
                        }
                    } else {
                        try (PreparedStatement ins = conn.prepareStatement(
                                "INSERT INTO pedidos_platillos(pedido_id, platillo_id, cantidad, precio_unitario) VALUES(?, ?, ?, ?)")) {
                            ins.setInt(1, pedidoId);
                            ins.setInt(2, platilloId);
                            ins.setInt(3, cantidad);
                            ins.setDouble(4, precio);
                            ins.executeUpdate();
                        }
                    }
                }
            }

            recalcularTotalPedido(pedidoId);
            loadPedidos();
            JOptionPane.showMessageDialog(this, "Platillo agregado/actualizado.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al agregar platillo: " + e.getMessage());
        }
    }

    private void cambiarCantidadDeItem(int pedidoId) {
        int platilloId;
        try {
            String s = JOptionPane.showInputDialog(this, "ID de platillo a modificar cantidad:");
            if (s == null) return;
            platilloId = Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID inválido.");
            return;
        }

        int cantidad;
        try {
            String s = JOptionPane.showInputDialog(this, "Nueva cantidad (>0):");
            if (s == null) return;
            cantidad = Integer.parseInt(s);
            if (cantidad <= 0) { JOptionPane.showMessageDialog(this, "La cantidad debe ser > 0."); return; }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Cantidad inválida.");
            return;
        }

        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE pedidos_platillos SET cantidad=? WHERE pedido_id=? AND platillo_id=?")) {
            ps.setInt(1, cantidad);
            ps.setInt(2, pedidoId);
            ps.setInt(3, platilloId);
            int n = ps.executeUpdate();
            if (n == 0) {
                JOptionPane.showMessageDialog(this, "Ese platillo no está en el pedido.");
                return;
            }
            recalcularTotalPedido(pedidoId);
            loadPedidos();
            JOptionPane.showMessageDialog(this, "Cantidad actualizada.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cambiar cantidad: " + e.getMessage());
        }
    }

    private void eliminarItemDePedido(int pedidoId) {
        int platilloId;
        try {
            String s = JOptionPane.showInputDialog(this, "ID de platillo a eliminar del pedido:");
            if (s == null) return;
            platilloId = Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID inválido.");
            return;
        }

        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM pedidos_platillos WHERE pedido_id=? AND platillo_id=?")) {
            ps.setInt(1, pedidoId);
            ps.setInt(2, platilloId);
            int n = ps.executeUpdate();
            if (n == 0) {
                JOptionPane.showMessageDialog(this, "Ese platillo no está en el pedido.");
                return;
            }
            if (existenItemsEnPedido(pedidoId)) {
                recalcularTotalPedido(pedidoId);
            }
            loadPedidos();
            JOptionPane.showMessageDialog(this, "Platillo eliminado del pedido.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar ítem: " + e.getMessage());
        }
    }

    private void recalcularTotalPedido(int pedidoId) throws SQLException {
        String sqlTotal = "UPDATE pedidos p SET total = (" +
                          "  SELECT COALESCE(SUM(pp.cantidad * pp.precio_unitario), 0) " +
                          "  FROM pedidos_platillos pp WHERE pp.pedido_id = p.id" +
                          ") WHERE p.id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sqlTotal)) {
            ps.setInt(1, pedidoId);
            ps.executeUpdate();
        }
    }

    private void eliminarPedido() {
        int selectedRow = pedidosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un pedido");
            return;
        }

        int pedidoId = (Integer) pedidosModel.getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar este pedido?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM pedidos WHERE id = ?")) {
                stmt.setInt(1, pedidoId);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Pedido eliminado correctamente.");
                    loadPedidos();
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo eliminar el pedido.");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar pedido: " + e.getMessage());
            }
        }
    }

    // ===================== REPORTES (UI) =====================
    private void mostrarReporteTotal() {
        String reporte = Main.reporteTotalPedidos(conn);

        JTextArea textArea = new JTextArea(reporte);
        textArea.setEditable(false);
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));

        JOptionPane.showMessageDialog(this, scrollPane, "Reporte Total de Pedidos", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarReportePorCliente() {
        String clienteIdStr = JOptionPane.showInputDialog(this, "ID del cliente:");
        if (clienteIdStr == null || clienteIdStr.trim().isEmpty()) return;

        try {
            int clienteId = Integer.parseInt(clienteIdStr);
            String reporte = Main.reportePedidosPorCliente(conn, clienteId);

            JTextArea textArea = new JTextArea(reporte);
            textArea.setEditable(false);
            textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(500, 400));

            JOptionPane.showMessageDialog(this, scrollPane, "Reporte por Cliente", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID de cliente inválido");
        }
    }

    // ===================== MAIN =====================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(RestauranteApp::new);
    }
}
